# coding: utf-8
from pulsar import provider
import xbmcaddon, xbmc, xbmcgui, os, thread

addon = xbmcaddon.Addon(id='script.pulsar.PirateBay')
url = os.path.join(addon.getSetting('url'),'')
troubleshoot = addon.getSetting('troubleshoot') == 'true'
movieQualityMap = {"Any":200,"DVD":202,"HD":207,"3D":209}
movieCategory = movieQualityMap[addon.getSetting('movieQuality')]
tvQualityMap = {"Any":200,"DVD":205,"HD":208}
tvCategory = tvQualityMap[addon.getSetting('tvQuality')]
searchSuffix = addon.getSetting('searchSuffix')
movieSuffix = addon.getSetting('movieSuffix')
tvSuffix = addon.getSetting('tvSuffix')

ok = xbmcgui.Dialog().ok

def asyncOk(header, line1, line2, line3):
  thread.start_new_thread(ok, (header, line1, line2, line3))

def magnetsFromPirateBay(query,suffix,category):
    if len(suffix) > 0:
        suffix = ' ' + suffix
    requestUrl = '%ssearch/%s%s/0/7/%s' % (url, query, suffix, category)
    if troubleshoot:
        asyncOk('Test this url in a browser', requestUrl, "If it gives you no torrents your video don't exist", "If it don't even show TPB please change url")
    response = provider.GET(requestUrl)
    return provider.extract_magnets(response.data)

def search(query):
    return magnetsFromPirateBay('%(query)s' % query, searchSuffix, 200)

def search_episode(episode):
    return magnetsFromPirateBay('%(title)s S%(season)02dE%(episode)02d' % episode, tvSuffix, tvCategory)

def search_movie(movie):
    return magnetsFromPirateBay('%(imdb_id)s' % movie, movieSuffix, movieCategory)

provider.register(search, search_movie, search_episode)
