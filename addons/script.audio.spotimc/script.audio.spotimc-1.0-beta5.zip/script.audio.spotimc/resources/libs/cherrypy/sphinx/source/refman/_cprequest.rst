**************************
:mod:`cherrypy._cprequest`
**************************

.. automodule:: cherrypy._cprequest

Classes
=======

.. autoclass:: Request
   :members:

.. autoclass:: Response
   :members:

.. autoclass:: Hook
   :members:

.. autoclass:: HookMap
   :members:


