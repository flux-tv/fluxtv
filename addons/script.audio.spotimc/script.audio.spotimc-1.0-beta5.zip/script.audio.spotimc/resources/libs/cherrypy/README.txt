* To install, change to the directory where setup.py is located and type (python-2.3 or later needed):

    python setup.py install

* To learn how to use it, look at the examples under cherrypy/tutorial/ or go to http://www.cherrypy.org for more info.

* To run the regression tests, just go to the cherrypy/test/ directory and type:

    nosetests -s ./

  Or to run individual tests type:

    nosetests -s test_foo.py
