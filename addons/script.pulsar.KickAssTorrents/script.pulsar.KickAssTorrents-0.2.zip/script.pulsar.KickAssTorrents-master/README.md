script.pulsar.KickAssTorrents
======================================
This script lets you access KickAssTorrents with Pulsar, the script is subject to change to make it more effective on KickAssTorrents.
